public class Driver {


    public static void main(String[] args) {
        try {
            FileSystem fs = new FileSystem();
            fs.create("Drive", "G", "");
            fs.create("Folder", "Documents", "G");
            fs.create("TextFile", "notes.txt", "G\\Documents");
            fs.create("TextFile", "notes1.txt", "G\\Documents");
            fs.create("TextFile", "notes3.txt", "G\\Documents");

            //output is 1 for drive
            System.out.println(fs.findEntity("G").getSize());

            //output is 3 for folder because of 3 files inside it
            System.out.println(fs.findEntity("G\\Documents").getSize());
            fs.writeToFile("G\\Documents\\notes.txt", "Hello file system");
//            fs.move("G\\Documents\\notes.txt", "G");

            //output is 17  for txt file(notes.txt)
            System.out.println(fs.findEntity("G\\Documents\\notes.txt").getSize());


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
