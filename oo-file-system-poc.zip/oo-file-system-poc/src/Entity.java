import java.util.ArrayList;
import java.util.List;

abstract class Entity {
    protected String name;
    protected Entity parent;

    public Entity(String name, Entity parent) {
        this.name = name;
        this.parent = parent;
    }

    public String getPath() {
        if (parent == null) {
            return name;
        }
        return parent.getPath() + "\\" + name;
    }

    public abstract int getSize();
}

class Drive extends Entity {
    private List<Entity> contents;

    public Drive(String name) {
        super(name, null);
        this.contents = new ArrayList<>();
    }

    public void addEntity(Entity entity) {
        contents.add(entity);
    }

    public void removeEntity(Entity entity) {
        contents.remove(entity);
    }

    @Override
    public int getSize() {
        int size = 0;
        for (Entity entity : contents) {
            size++;
        }
        return size;
    }

    public List<Entity> getContents() {
        return contents;
    }
}

class Folder extends Entity {
    private List<Entity> contents;

    public Folder(String name, Entity parent) {
        super(name, parent);
        this.contents = new ArrayList<>();
    }

    public void addEntity(Entity entity) {
        contents.add(entity);
    }

    public void removeEntity(Entity entity) {
        contents.remove(entity);
    }

    @Override
    public int getSize() {
        int size = 0;
        for (Entity entity : contents) {
            size++;
        }
        return size;
    }

    public List<Entity> getContents() {
        return contents;
    }
}

class TextFile extends Entity {
    private String content;

    public TextFile(String name, Entity parent, String content) {
        super(name, parent);
        this.content = content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public int getSize() {
        return content.length();
    }
}
