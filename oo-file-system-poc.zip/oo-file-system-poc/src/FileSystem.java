import java.util.HashMap;
import java.util.Map;

class FileSystem {
    private Map<String, Drive> drives;

    public FileSystem() {
        this.drives = new HashMap<>();
    }

    public Entity findEntity(String path) throws Exception {
        String[] parts = path.split("\\\\");
        if (!drives.containsKey(parts[0])) {
            throw new Exception("Path not found");
        }

        Entity entity = drives.get(parts[0]);
        for (int i = 1; i < parts.length; i++) {
            entity = findInContents(entity, parts[i]);
            if (entity == null) {
                throw new Exception("Path not found");
            }
        }
        return entity;
    }

    private Entity findInContents(Entity parent, String name) {
        if (parent instanceof Drive) {
            for (Entity entity : ((Drive) parent).getContents()) {
                if (entity.name.equals(name)) {
                    return entity;
                }
            }
        } else if (parent instanceof Folder) {
            for (Entity entity : ((Folder) parent).getContents()) {
                if (entity.name.equals(name)) {
                    return entity;
                }
            }
        }
        return null;
    }

    public void create(String entityType, String name, String parentPath) throws Exception {
        if (entityType.equals("Drive")) {
            if (drives.containsKey(name)) {
                throw new Exception("Drive already exists");
            }
            drives.put(name, new Drive(name));
        } else {
            Entity parent = findEntity(parentPath);
            if (findInContents(parent, name) != null) {
                throw new Exception("Path already exists");
            }

            Entity newEntity;
            switch (entityType) {
                case "Folder":
                    newEntity = new Folder(name, parent);
                    break;
                case "TextFile":
                    newEntity = new TextFile(name, parent, "");
                    break;
                default:
                    throw new Exception("Invalid entity type");
            }

            if (parent instanceof Drive) {
                ((Drive) parent).addEntity(newEntity);
            } else if (parent instanceof Folder) {
                ((Folder) parent).addEntity(newEntity);
            }
        }
    }

    public void move(String sourcePath, String destinationPath) throws Exception {
        Entity entity = findEntity(sourcePath);
        Entity newParent = findEntity(destinationPath);

        if (newParent instanceof TextFile) {
            throw new Exception("Illegal File System Operation");
        }

        Entity oldParent = entity.parent;
        if (oldParent instanceof Drive) {
            ((Drive) oldParent).removeEntity(entity);
        } else if (oldParent instanceof Folder) {
            ((Folder) oldParent).removeEntity(entity);
        }

        entity.parent = newParent;
        if (newParent instanceof Drive) {
            ((Drive) newParent).addEntity(entity);
        } else if (newParent instanceof Folder) {
            ((Folder) newParent).addEntity(entity);
        }
    }

    public void writeToFile(String path, String content) throws Exception {
        Entity entity = findEntity(path);
        if (!(entity instanceof TextFile)) {
            throw new Exception("Not a text file");
        }
        ((TextFile) entity).setContent(content);
    }
}
